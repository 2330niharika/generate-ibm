from pydantic import BaseModel

class EcoTipsInput(BaseModel):
    topic: str